package logica;

public class inicializar {

	public static void main(String[] args) throws Exception{
		
	
	//Relaci�n Universidad (1) - (1..N) Escuela es Unidireccional, Escuela no mantiene una referencia a Universidad
	Universidad u=new Universidad("UPV");
	Escuela e=new Escuela("ETSINF"); // La Escuela (e) se inicializa con la instancia de Universidad (u)
	u.addEscuela(e); //Se a�ade la Escuela (e) a la lista de Escuelas de la Universidad (u)
	
	//Relaci�n Escuela (1) - (*) Profesor Bidireccional
	Profesor p=new Profesor("00000000Z","Antonio Molina",32,e); //El Profesor (p) se inicializa con la instancia de Escuela (e)
	e.addProfesor(p); //Se a�ade el Profesor (p) a la lista de Profesores adscritos a la Escuela (e) 

	//Relacion Escuela (1) - (1..N) Titulacion Bidireccional: inicializaci�n en dos pasos. La Escuela se ha incializado arriba
	//Titulacion es clase abstracta, se crean instancias de las clases derivadas Grado y Master
	Titulacion grado=new Grado(240,"Grado en Ingenier�a Inform�tica",156,2009,e); //La Titulaci�n (grado) se inicializa con la instancia de Escuela (e)
	Titulacion master=new Master(120,"Master en Ingenier�a Inform�tica",2233,2014,e,'P'); //La Titulaci�n (master) se inicializa con la instancia de Escuela (e)
	e.addTitulacion(grado); //Se a�ade la Titulacion (grado) a la lista de Titulaciones impartidas por la Escuela (e)
	e.addTitulacion(master); //Se a�ade la Titulacion (master) a la lista de Titulaciones impartidas por la Escuela (e)
	
	// Relaci�n Universidad (1) - (1..N) Titulaci�n es Unidireccional, Titulaci�n no mantiene una referencia a Universidad
	u.addTitulacion(grado);
	u.addTitulacion(master);
	
	//Clase Asociaci�n DocenciaImpartida
	DocenciaImpartida di_grado = new DocenciaImpartida(p,grado,15,'C');
	DocenciaImpartida di_master = new DocenciaImpartida(p,master,6,'C');
	//Para mantener la bidireccionalidad con Titulacion y Profesor:
	grado.addDI(di_grado); //Se a�ade la DocenciaImpartida (di_grado) a la lista de docencia impartida en la Titulacion (grado)
	master.addDI(di_master); //Se a�ade la DocenciaImpartida (di_master) a la lista de docencia impartida en la Titulacion (master)
	p.addDI(di_grado); //Se a�ade la DocenciaImpartida (di_grado) a la lista de docencia impartida por el Profesor (p) 
	p.addDI(di_master); //Se a�ade la DocenciaImpartida (di_master) a la lista de docencia impartida por el Profesor (p) 
	}
}
