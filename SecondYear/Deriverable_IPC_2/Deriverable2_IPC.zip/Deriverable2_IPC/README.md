# Deriverable2_IPC

## Fitness app that works with GPX files

Second deriverable for the lab assessments.
It's a JavaFX interface that allows the user to import a GPX file.

 * [Jose Collado] (mailto:jocolsan@inf.upv.es) 



