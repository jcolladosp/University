package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author jcolladosp
 */
public class Deriverable_2 extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
        
        
        Scene scene = new Scene(root);
        
        stage.setTitle("Main Screen - RotoSoft");
        stage.setScene(scene);
        stage.setMinWidth(400);
        stage.setMinHeight(430);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
