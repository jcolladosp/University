package logica;

public class DocenciaImpartida {
	private Profesor profesor;
	private Titulacion titulacion;
	int creditos_impartidos;
	char idioma; // C:castellano; V:valenciano; I: ingl�s
	public DocenciaImpartida(Profesor profesor, Titulacion titulacion,
			int creditos_impartidos, char idioma) {
		this.profesor = profesor;
		this.titulacion = titulacion;
		this.creditos_impartidos = creditos_impartidos;
		this.idioma = idioma;
	}
	public Profesor getProfesor() {
		return profesor;
	}
	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}
	public Titulacion getTitulacion() {
		return titulacion;
	}
	public void setTitulacion(Titulacion titulacion) {
		this.titulacion = titulacion;
	}
	public int getCreditos_impartidos() {
		return creditos_impartidos;
	}
	public void setCreditos_impartidos(int creditos_impartidos) {
		this.creditos_impartidos = creditos_impartidos;
	}
	public char getIdioma() {
		return idioma;
	}
	public void setIdioma(char idioma) {
		this.idioma = idioma;
	}
	
}
