package logica;

import java.util.ArrayList;

public class Universidad {
private String nombre;
private ArrayList<Escuela> listaEscuelas;
private ArrayList<Titulacion> listaTitulaciones;

public Universidad(String nombre) {
	this.nombre = nombre;
	listaEscuelas = new ArrayList<Escuela>();
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public ArrayList<Escuela> getListaEscuelas() {
	return listaEscuelas;
}

public void setListaEscuelas(ArrayList<Escuela> listaEscuelas) {
	this.listaEscuelas = listaEscuelas;
}

public void addEscuela(Escuela escuela) throws Exception{
	if (buscaEscuela(escuela.getNombre())==null)
		listaEscuelas.add(escuela);
	else throw new Exception();
}

public Escuela buscaEscuela(String nombre){
	for(Escuela e:listaEscuelas){
		if(e.getNombre()==nombre) return e;
	}
	return null;
}

public void addTitulacion(Titulacion titulacion) throws Exception{
	if (buscaTitulacion(titulacion.getCodigo())==null)
		listaTitulaciones.add(titulacion);
	else throw new Exception();
}

public Titulacion buscaTitulacion(int cod){
	for(Titulacion t:listaTitulaciones){
		if(t.getCodigo()==cod) return t;
	}
	return null;
}
}
