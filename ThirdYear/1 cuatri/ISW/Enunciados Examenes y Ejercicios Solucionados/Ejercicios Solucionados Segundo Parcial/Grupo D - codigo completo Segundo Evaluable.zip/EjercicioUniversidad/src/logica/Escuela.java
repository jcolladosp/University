package logica;

import java.util.ArrayList;

public class Escuela {
private String nombre;
private ArrayList <Profesor> profAdscritos;
private ArrayList <Titulacion> titulacionesImpartidas;

public Escuela(String nombre) {
	this.nombre = nombre;
	profAdscritos=new ArrayList <Profesor>();
	titulacionesImpartidas=new ArrayList <Titulacion>();
}
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}

public ArrayList<Profesor> getProfAdscritos() {
	return profAdscritos;
}
public void setProfAdscritos(ArrayList<Profesor> profAdscritos) {
	this.profAdscritos = profAdscritos;
}
public void addProfesor(Profesor profesor) throws Exception{
	if (buscaProfesor(profesor.getDni())==null)
		profAdscritos.add(profesor);
	else throw new Exception();
}

public Profesor buscaProfesor(String dni){
	for(Profesor p:profAdscritos){
		if(p.getDni()==dni) return p;
	}
	return null;
}
public ArrayList<Titulacion> getTitulacionesImpartidas() {
	return titulacionesImpartidas;
}
public void setTitulacionesImpartidas(
		ArrayList<Titulacion> titulacionesImpartidas) {
	this.titulacionesImpartidas = titulacionesImpartidas;
}
public void addTitulacion(Titulacion titulacion) throws Exception{
	if (buscaTitulacion(titulacion.getCodigo())==null)
		titulacionesImpartidas.add(titulacion);
	else throw new Exception();
}

public Titulacion buscaTitulacion(int cod){
	for(Titulacion t:titulacionesImpartidas){
		if(t.getCodigo()==cod) return t;
	}
	return null;
}

}
