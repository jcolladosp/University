package logica;

import java.util.ArrayList;

public class Profesor {
private String dni;
private String nombre;
private int max_creditos_impartir;
private boolean excede_creditos_impartidos;
private Escuela escuela;
private ArrayList<DocenciaImpartida> listaDocenciaImpartida;

public Profesor(String dni, String nombre, int max_creditos,
		Escuela escuela) {
	this.dni = dni;
	this.nombre = nombre;
	this.max_creditos_impartir = max_creditos;
	this.excede_creditos_impartidos = false;
	this.escuela = escuela;
	listaDocenciaImpartida=new ArrayList<DocenciaImpartida>();
}
public String getDni() {
	return dni;
}
public void setDni(String dni) {
	this.dni = dni;
}
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public int getMax_creditos() {
	return max_creditos_impartir;
}
public void setMax_creditos(int max_creditos) {
	this.max_creditos_impartir = max_creditos;
}
public boolean isExcede_creditos() {
	return excede_creditos_impartidos;
}
public void setExcede_creditos(boolean excede_creditos) {
	this.excede_creditos_impartidos = excede_creditos;
}
public Escuela getEscuela() {
	return escuela;
}
public void setEscuela(Escuela escuela) {
	this.escuela = escuela;
}
public void addDI(DocenciaImpartida di) throws Exception{
	if (buscaDI(di.getTitulacion())==null)
		listaDocenciaImpartida.add(di);
	else throw new Exception();
}

public DocenciaImpartida buscaDI(Titulacion t){
	for(DocenciaImpartida di:listaDocenciaImpartida){
		if(di.getTitulacion().getCodigo()==t.getCodigo()) return di;
	}
	return null;
}

public int calculaCr�ditosImpartidos(){
	int creditosImpartidos=0;
	for(DocenciaImpartida di:listaDocenciaImpartida){
		creditosImpartidos+=di.getCreditos_impartidos();
		}
	return creditosImpartidos;
}
}
