package logica;

public class Master extends Titulacion {
private char caracter; //P:profesional, C:cient�fico

public Master(int total_ects, String denominacion, int codigo, 
		int plan_de_estudios, Escuela escuela, char caracter) {
	super(total_ects, denominacion, codigo, plan_de_estudios, escuela);
	this.caracter = caracter;
}

public char getCaracter() {
	return caracter;
}

public void setCaracter(char caracter) {
	this.caracter = caracter;
}

}
