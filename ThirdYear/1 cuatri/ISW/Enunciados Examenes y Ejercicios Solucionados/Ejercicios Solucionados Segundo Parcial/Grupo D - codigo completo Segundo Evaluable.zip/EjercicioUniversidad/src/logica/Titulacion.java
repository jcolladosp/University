package logica;
import java.util.ArrayList;

public abstract class Titulacion {
private int codigo;
private int total_ects;
private String denominacion;
private int plan_de_estudios;
private Escuela escuela;
private ArrayList<DocenciaImpartida> listaDocenciaImpartida;

public Titulacion(int total_ects, String denominacion,int codigo, 
		int plan_de_estudios, Escuela escuela) {
	this.codigo = codigo;
	this.total_ects = total_ects;
	this.denominacion = denominacion;
	this.plan_de_estudios = plan_de_estudios;
	this.escuela = escuela;
	listaDocenciaImpartida=new ArrayList<DocenciaImpartida>();
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public int getTotal_ects() {
	return total_ects;
}
public void setTotal_ects(int total_ects) {
	this.total_ects = total_ects;
}
public String getDenominacion() {
	return denominacion;
}
public void setDenominacion(String denominacion) {
	this.denominacion = denominacion;
}
public int getPlan_de_estudios() {
	return plan_de_estudios;
}
public void setPlan_de_estudios(int plan_de_estudios) {
	this.plan_de_estudios = plan_de_estudios;
}
public Escuela getEscuela() {
	return escuela;
}
public void setEscuela(Escuela escuela) {
	this.escuela = escuela;
}
public ArrayList<DocenciaImpartida> getListaDocenciaImpartida() {
	return listaDocenciaImpartida;
}
public void setListaDocenciaImpartida(
		ArrayList<DocenciaImpartida> listaDocenciaImpartida) {
	this.listaDocenciaImpartida = listaDocenciaImpartida;
}
public void addDI(DocenciaImpartida di) throws Exception{
	if (buscaDI(di.getProfesor())==null)
		listaDocenciaImpartida.add(di);
	else throw new Exception();
}

public DocenciaImpartida buscaDI(Profesor p){
	for(DocenciaImpartida di:listaDocenciaImpartida){
		if(di.getProfesor().getDni()==p.getDni()) return di;
	}
	return null;
}
}
