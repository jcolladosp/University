package logica;

public class Grado extends Titulacion {

	public Grado(int total_ects, String denominacion, int codigo, 
			int plan_de_estudios, Escuela escuela) {
		super(total_ects, denominacion, codigo, plan_de_estudios, escuela);
	}

}
